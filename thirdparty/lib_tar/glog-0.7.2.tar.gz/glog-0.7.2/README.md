1. 编译glog，并安装到系统

``` bash
mkdir build && cd build
cmake .. -DWITH_UNWIND=none
make -j
sudo make install
```

2. 打包为压缩文件

``` bash
cd scripts
bash package_glog.sh
```